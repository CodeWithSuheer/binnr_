import HomePageList from "../../sections/landingPage/view/HomePageList";

const LandingPage = () => {
  return (
    <>
      <HomePageList />
    </>
  );
};

export default LandingPage;
